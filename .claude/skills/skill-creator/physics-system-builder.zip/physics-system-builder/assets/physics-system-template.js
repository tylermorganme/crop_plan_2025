/**
 * [PHYSICS SYSTEM NAME]
 *
 * [Brief description of what this physics system does and how it works]
 */

export default {
  name: "[System Name]",
  description: "[Brief description shown in UI]",

  // Define tunable parameters
  controls: {
    // Example range control
    myParameter: {
      type: 'range',
      min: 0,
      max: 100,
      step: 1,
      default: 50,
      label: 'My Parameter Label'
    },

    // Example checkbox control
    enableFeature: {
      type: 'checkbox',
      default: true,
      label: 'Enable Feature'
    }

    // Add more controls as needed
  },

  // Internal state (if needed)
  // velocities: null,
  // grid: null,

  /**
   * Initialize the physics system
   * Called once when the system is loaded
   *
   * @param {Object} settings - All control values
   * @param {Object} entities - Entity data (count, x[], y[], type[])
   * @param {Object} canvasInfo - Canvas dimensions and margins
   */
  init(settings, entities, canvasInfo) {
    // Initialize any data structures you need
    // Example:
    // this.velocities = {
    //   x: new Float32Array(100000),
    //   y: new Float32Array(100000)
    // };
  },

  /**
   * Update entity positions
   * Called every frame
   *
   * @param {number} dt - Delta time in seconds
   * @param {Object} settings - All control values
   * @param {Object} entities - Entity data to modify
   * @param {Object} input - Player and mouse position
   */
  update(dt, settings, entities, input) {
    // Main physics logic goes here
    // Iterate over entities and update their positions

    for (let i = 0; i < entities.count; i++) {
      // Calculate movement
      // Example: Move toward player
      let dx = input.x - entities.x[i];
      let dy = input.y - entities.y[i];

      // Normalize direction
      const len = Math.sqrt(dx * dx + dy * dy);
      if (len > 0) {
        dx /= len;
        dy /= len;
      }

      // Update position
      entities.x[i] += dx * settings.speed * dt;
      entities.y[i] += dy * settings.speed * dt;
    }
  },

  /**
   * Custom rendering (optional)
   * Draw debug visualizations like vectors, grids, zones
   *
   * @param {CanvasRenderingContext2D} ctx - Canvas context
   * @param {Object} settings - All control values
   * @param {Object} entities - Entity data
   * @param {boolean} debugMode - Debug mode flag
   */
  render(ctx, settings, entities, debugMode) {
    // Optional: Draw debug visualizations
    // Example:
    // if (!settings.showDebug) return;
    //
    // ctx.strokeStyle = '#ff00ff';
    // ctx.lineWidth = 1;
    // // Draw something...
  },

  /**
   * Cleanup (optional)
   * Called when switching to another physics system
   */
  cleanup() {
    // Release memory, clear intervals, etc.
    // Example:
    // this.velocities = null;
  }
};
