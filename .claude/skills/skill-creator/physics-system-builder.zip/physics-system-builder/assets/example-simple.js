/**
 * Simple Kinematic Physics System
 *
 * Basic seek behavior with no collision avoidance.
 * Useful as a baseline for performance comparison.
 */

export default {
  name: "Simple Kinematic",
  description: "Direct seek with no collision avoidance",

  controls: {
    // This system has no special controls, just uses common speed setting
  },

  update(dt, settings, entities, input) {
    // Simple: Move directly toward player
    for (let i = 0; i < entities.count; i++) {
      // Calculate direction to player
      let dirX = input.x - entities.x[i];
      let dirY = input.y - entities.y[i];
      let len = Math.sqrt(dirX * dirX + dirY * dirY);

      if (len > 0) {
        // Normalize
        dirX /= len;
        dirY /= len;

        // Move
        entities.x[i] += dirX * settings.speed * dt;
        entities.y[i] += dirY * settings.speed * dt;
      }
    }
  }
};
