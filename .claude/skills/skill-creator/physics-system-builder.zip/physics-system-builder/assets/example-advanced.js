/**
 * Velocity-Based Physics System
 *
 * Traditional physics with velocity, acceleration, and simple separation.
 */

export default {
  name: "Velocity-Based Physics",
  description: "Traditional velocity/acceleration with separation force",

  controls: {
    maxForce: {
      type: 'range',
      min: 0,
      max: 2000,
      step: 10,
      default: 800,
      label: 'Max Steering Force'
    },
    separationRadius: {
      type: 'range',
      min: 5,
      max: 100,
      step: 5,
      default: 30,
      label: 'Separation Radius'
    },
    separationStrength: {
      type: 'range',
      min: 0,
      max: 500,
      step: 10,
      default: 100,
      label: 'Separation Strength'
    }
  },

  // Velocity storage (initialized on first update)
  velocities: null,

  update(dt, settings, entities, input) {
    // Initialize velocities if needed
    if (!this.velocities || this.velocities.x.length < entities.count) {
      this.velocities = {
        x: new Float32Array(100000),
        y: new Float32Array(100000)
      };
    }

    const maxSpeed = settings.speed;
    const maxForce = settings.maxForce;
    const sepRadius = settings.separationRadius;
    const sepStrength = settings.separationStrength;

    // Update each entity
    for (let i = 0; i < entities.count; i++) {
      let forceX = 0;
      let forceY = 0;

      // 1. SEEK FORCE (toward player)
      let seekX = input.x - entities.x[i];
      let seekY = input.y - entities.y[i];
      let seekLen = Math.sqrt(seekX * seekX + seekY * seekY);
      if (seekLen > 0) {
        seekX = (seekX / seekLen) * maxSpeed - this.velocities.x[i];
        seekY = (seekY / seekLen) * maxSpeed - this.velocities.y[i];

        // Limit to max force
        let seekForceLen = Math.sqrt(seekX * seekX + seekY * seekY);
        if (seekForceLen > maxForce) {
          seekX = (seekX / seekForceLen) * maxForce;
          seekY = (seekY / seekForceLen) * maxForce;
        }

        forceX += seekX;
        forceY += seekY;
      }

      // 2. SEPARATION FORCE (avoid neighbors)
      let sepX = 0;
      let sepY = 0;
      let neighborCount = 0;

      // Check nearby entities (simple O(n²) for now)
      for (let j = 0; j < entities.count; j++) {
        if (i === j) continue;

        const dx = entities.x[i] - entities.x[j];
        const dy = entities.y[i] - entities.y[j];
        const distSq = dx * dx + dy * dy;

        if (distSq > 0 && distSq < sepRadius * sepRadius) {
          const dist = Math.sqrt(distSq);
          sepX += (dx / dist) * (1 - dist / sepRadius);
          sepY += (dy / dist) * (1 - dist / sepRadius);
          neighborCount++;
        }
      }

      if (neighborCount > 0) {
        sepX = (sepX / neighborCount) * sepStrength;
        sepY = (sepY / neighborCount) * sepStrength;

        // Limit separation force
        let sepForceLen = Math.sqrt(sepX * sepX + sepY * sepY);
        if (sepForceLen > maxForce) {
          sepX = (sepX / sepForceLen) * maxForce;
          sepY = (sepY / sepForceLen) * maxForce;
        }

        forceX += sepX;
        forceY += sepY;
      }

      // 3. APPLY FORCES
      this.velocities.x[i] += forceX * dt;
      this.velocities.y[i] += forceY * dt;

      // Limit velocity to max speed
      const velLen = Math.sqrt(
        this.velocities.x[i] * this.velocities.x[i] +
        this.velocities.y[i] * this.velocities.y[i]
      );
      if (velLen > maxSpeed) {
        this.velocities.x[i] = (this.velocities.x[i] / velLen) * maxSpeed;
        this.velocities.y[i] = (this.velocities.y[i] / velLen) * maxSpeed;
      }

      // 4. UPDATE POSITION
      entities.x[i] += this.velocities.x[i] * dt;
      entities.y[i] += this.velocities.y[i] * dt;
    }
  },

  cleanup() {
    this.velocities = null;
  }
};
