# Game Design Context: Survivor-Style Physics

## Game Genre

This testbed is designed for **Vampire Survivors-style games** (also called "survivor-like" or "bullet heaven" games).

### Core Mechanics
- Single player character at center
- Thousands of enemies spawning continuously
- All enemies seek/chase the player
- Player can push/knock back enemies
- Enemies should occupy their own space (minimize overlap)

### Target Performance
- **Realistic goal:** 10,000 entities at 60 FPS

## The Core Physics Challenge

### The Problem

This is an exceptionally difficult physics problem due to several compounding factors:

1. **Convergent Movement**
   - All entities move toward the same point (player)
   - Creates natural clustering behavior
   - Maximizes simultaneous collisions

2. **Highest Density at Goal**
   - Density peaks at the player position (worst case)
   - Enemies stack up where they're trying to go
   - Creates "traffic jam" at destination

3. **Mass Movement**
   - Once clustered, enemies tend to move as a unified mass
   - Even when player moves away, the cluster persists
   - Entire swarm influences each other (O(n²) worst case)

4. **Overlapping Tendency**
   - Bodies pushing toward same goal naturally overlap
   - Traditional separation forces fight against seek behavior
   - Easy to create "vibrating" or "jittering" masses

5. **Player Interaction**
   - Player should be able to push enemies around
   - Enemies should move aggressively but not be immovable
   - Need balance between "threatening" and "manipulable"

## Design Goals for Physics Systems

When implementing a new physics system, consider:

### Performance Targets
- 10,000 entities at 60 FPS (minimum)
- Degrade gracefully above target
- Use spatial partitioning for neighbor queries
- Profile with realistic scenarios (clustered, not uniform)

### Visual Quality
- Minimal overlap (enemies should be distinguishable)
- Individual entities still visible

### Game Feel
- Enemies feel aggressive and threatening

### Tunability
- Parameters should have intuitive effects
- Wide range of viable parameter combinations
- Easy to find "sweet spot" for desired feel
- Clear trade-offs between conflicting goals
   - Test at 20k, 50k, 100k entities
   - Identify performance breaking points
   - Find where visual quality degrades

### Metrics to Monitor

- **FPS** - Should maintain 60 at target count
- **Entity overlap** - Visual inspection, count stacked entities
- **Player mobility** - Can player move through crowd?

## Future Directions

Potential physics improvements to explore:

- **GPU compute shaders** - Offload to WebGPU for massive parallelism
- **Adaptive resolution** - Finer grid near player, coarser far away
- **Predictive fields** - Incorporate player velocity
- **Multi-layer forces** - Long-range flow + short-range collision
- **Velocity obstacles** - Path planning around predicted collisions
- **Asymmetric forces** - Different push strengths for different scenarios
- **Clusters** - Take advantage of the facts that enemies are clustered.
- **Create Space** - Entities farther out have more freedom of movement that those at the center.
