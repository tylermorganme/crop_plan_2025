# Physics System API Reference

## Module Structure

Every physics system must be a JavaScript ES6 module that exports a default object:

```javascript
export default {
  name: String,              // Required
  description: String,       // Required
  controls: Object,          // Optional
  init: Function,            // Optional
  update: Function,          // Required
  render: Function,          // Optional
  cleanup: Function          // Optional
};
```

## Required Properties

### name
- Type: `String`
- Description: Display name shown in the physics selector dropdown
- Example: `"Boids Flocking"`

### description
- Type: `String`
- Description: Brief explanation of what the system does, shown below the title
- Example: `"Craig Reynolds' boids algorithm with alignment, cohesion, and separation"`

### update
- Type: `Function`
- Signature: `update(dt, settings, entities, input)`
- Description: Called every frame to update entity positions
- **This is the core physics logic**

#### Parameters:

**dt** (Number)
- Delta time in seconds since last frame
- Clamped to maximum of 0.1 to prevent physics explosions
- Typical value: ~0.016 (60 FPS)

**settings** (Object)
- Contains all control values (both common and physics-specific)
- Common settings available to all systems:
  - `settings.spawnRate` (Number) - Entities spawned per frame
  - `settings.speed` (Number) - Base movement speed
  - `settings.autoSpawn` (Boolean) - Auto-spawn enabled
- Plus all physics-specific controls defined in `controls` property

**entities** (Object)
- Entity data structure with:
  - `count` (Number) - Current number of active entities
  - `x` (Float32Array) - X positions, indexed [0...count-1]
  - `y` (Float32Array) - Y positions, indexed [0...count-1]
  - `type` (Uint8Array) - Entity types (reserved for future use)
- Maximum capacity: 100,000 entities
- **Modify `entities.x[i]` and `entities.y[i]` directly**

**input** (Object)
- Player and mouse input state:
  - `x` (Number) - Player X position
  - `y` (Number) - Player Y position
  - `targetX` (Number) - Player destination X
  - `targetY` (Number) - Player destination Y
  - `mouseX` (Number) - Current mouse X
  - `mouseY` (Number) - Current mouse Y
  - `manualSpawn` (Boolean) - User is holding mouse down

## Optional Properties

### controls
- Type: `Object`
- Description: Defines physics-specific parameters and UI controls
- Each key becomes a property in the `settings` object

#### Control Definition:

```javascript
controls: {
  myParameter: {
    type: 'range' | 'checkbox',
    min: Number,           // For 'range' only
    max: Number,           // For 'range' only
    step: Number,          // For 'range' only
    default: Number | Boolean,
    label: String,         // Human-readable label
    onChange: Function     // Optional callback(value, engine)
  }
}
```

#### Examples:

```javascript
controls: {
  cohesionRadius: {
    type: 'range',
    min: 10,
    max: 200,
    step: 5,
    default: 50,
    label: 'Cohesion Radius (px)'
  },
  enableSeparation: {
    type: 'checkbox',
    default: true,
    label: 'Enable Separation Force'
  },
  gridResolution: {
    type: 'range',
    min: 5,
    max: 50,
    step: 1,
    default: 20,
    label: 'Spatial Grid Cell Size',
    onChange: (value, engine) => {
      // Re-initialize grid when resolution changes
      engine.physicsSystem.rebuildGrid(value);
    }
  }
}
```

### init
- Type: `Function`
- Signature: `init(settings, entities, canvasInfo)`
- Description: Called once when physics system is loaded
- Use for: Initializing data structures, allocating memory, setting up grids

#### Parameters:

**settings** (Object) - Same as in `update()`

**entities** (Object) - Same as in `update()`

**canvasInfo** (Object)
- Canvas dimensions and simulation bounds:
  - `width` (Number) - Canvas width in pixels
  - `height` (Number) - Canvas height in pixels
  - `simWidth` (Number) - Simulation width (includes margin)
  - `simHeight` (Number) - Simulation height (includes margin)
  - `margin` (Number) - Extra space around canvas (default: 500)

#### Example:

```javascript
init(settings, entities, canvasInfo) {
  this.velocities = {
    x: new Float32Array(100000),
    y: new Float32Array(100000)
  };

  this.grid = this.createSpatialGrid(
    canvasInfo.simWidth,
    canvasInfo.simHeight,
    settings.gridResolution
  );
}
```

### render
- Type: `Function`
- Signature: `render(ctx, settings, entities, debugMode)`
- Description: Called after entities are rendered, for debug visualizations
- Use for: Drawing gradient fields, velocity vectors, spatial grids, zones

#### Parameters:

**ctx** (CanvasRenderingContext2D)
- Canvas 2D rendering context
- Canvas is already cleared and entities already drawn
- Your rendering is overlaid on top

**settings** (Object) - Same as in `update()`

**entities** (Object) - Same as in `update()`

**debugMode** (Boolean)
- Currently always `false` (reserved for future use)
- Can check custom settings like `settings.showGrid` instead

#### Example:

```javascript
render(ctx, settings, entities, debugMode) {
  if (!settings.showVectors) return;

  ctx.strokeStyle = '#ff00ff';
  ctx.lineWidth = 1;
  ctx.beginPath();

  for (let i = 0; i < Math.min(entities.count, 1000); i += 10) {
    const vx = this.velocities.x[i];
    const vy = this.velocities.y[i];
    const x = entities.x[i];
    const y = entities.y[i];

    ctx.moveTo(x, y);
    ctx.lineTo(x + vx * 10, y + vy * 10);
  }

  ctx.stroke();
}
```

### cleanup
- Type: `Function`
- Signature: `cleanup()`
- Description: Called when switching to a different physics system
- Use for: Releasing memory, clearing intervals, cleanup

#### Example:

```javascript
cleanup() {
  this.velocities = null;
  this.grid = null;
  if (this.worker) {
    this.worker.terminate();
  }
}
```

## Canvas Coordinate System

- Origin (0, 0) is at top-left corner of visible canvas
- X increases rightward
- Y increases downward
- Entities can exist outside visible area (margin space)
- Coordinate range:
  - X: [-margin, width + margin]
  - Y: [-margin, height + margin]
  - Default margin: 500px

## Performance Considerations

### Memory

- All arrays are pre-allocated to 100,000 capacity
- Use TypedArrays for additional state (Float32Array, Uint8Array)
- Avoid creating new objects/arrays in the update loop

### Entity Iteration

```javascript
// Good - direct array access
for (let i = 0; i < entities.count; i++) {
  entities.x[i] += dx;
  entities.y[i] += dy;
}

// Bad - creates temporary objects
entities.x.forEach((x, i) => { /* ... */ });
```

### Neighbor Queries

O(n²) neighbor checks become expensive above ~5000 entities:

```javascript
// Bad for large N
for (let i = 0; i < entities.count; i++) {
  for (let j = i + 1; j < entities.count; j++) {
    // Check distance...
  }
}

// Better - use spatial hashing/grid
const neighbors = this.grid.queryRadius(entities.x[i], entities.y[i], radius);
for (const j of neighbors) {
  // Only check nearby entities
}
```

### Distance Checks

```javascript
// Good - avoid sqrt when possible
const dx = x2 - x1;
const dy = y2 - y1;
const distSq = dx * dx + dy * dy;
if (distSq < radiusSq) {
  // In range
}

// Bad - unnecessary sqrt
const dist = Math.sqrt(dx * dx + dy * dy);
if (dist < radius) { /* ... */ }
```

## Hot Module Replacement

When your physics file is saved, Vite will hot-reload it:

1. The `cleanup()` function is called on the old module
2. The new module is imported
3. `init()` is called on the new module
4. Simulation continues with existing entities preserved

**Note:** Internal state (like `this.velocities`) will be reset. Entity positions (`entities.x/y`) are preserved.

## Common Patterns

### Storing Velocities

```javascript
export default {
  velocities: null,

  update(dt, settings, entities, input) {
    // Lazy initialization
    if (!this.velocities) {
      this.velocities = {
        x: new Float32Array(100000),
        y: new Float32Array(100000)
      };
    }

    // Use velocities...
  }
};
```

### Normalizing Vectors

```javascript
let dx = targetX - x;
let dy = targetY - y;
const len = Math.sqrt(dx * dx + dy * dy);

if (len > 0) {
  dx /= len;
  dy /= len;
  // Now dx, dy is a unit vector
}
```

### Clamping Speed

```javascript
const vx = this.velocities.x[i];
const vy = this.velocities.y[i];
const speed = Math.sqrt(vx * vx + vy * vy);

if (speed > maxSpeed) {
  this.velocities.x[i] = (vx / speed) * maxSpeed;
  this.velocities.y[i] = (vy / speed) * maxSpeed;
}
```
