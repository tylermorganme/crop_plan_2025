---
name: physics-system-builder
description: This skill should be used when the user wants to create a new physics system for the survivor-physics testbed. It provides templates, workflow guidance, and examples for implementing modular physics systems that integrate with the testbed infrastructure.
---

# Physics System Builder

## Overview

This skill guides the creation of new physics systems for the survivor-physics testbed. It provides templates and workflows for implementing modular physics implementations that work with the shared simulation engine, renderer, and control panel.

## When to Use This Skill

Use this skill when:
- User asks to create a new physics system
- User wants to implement a specific physics algorithm (e.g., "add boids flocking", "create GPU-based physics", "implement spatial hashing")
- User requests to port an existing physics implementation to the testbed
- User wants to experiment with crowd behavior, collision avoidance, or movement algorithms

## Physics System Structure

All physics systems in the testbed follow a standard interface defined in `references/physics-system-api.md`. Each system is a JavaScript module that exports a default object with:

1. **Metadata** - Name and description
2. **Controls** - Parameter definitions for the UI
3. **Lifecycle hooks** - init(), update(), render(), cleanup()

## Creating a New Physics System

### Step 1: Understand the Requirements

First, review `references/game-design-context.md` to understand the unique challenges of survivor-style game physics.

**Standing Requirements:**
- **All relevant parameters should be tunable** - Expose any value that affects behavior
- **Always search for reference implementations and papers** - Look for academic work, existing implementations, and prior art
- **Performance > Accuracy** - This is a game, not an engineering simulation. Feel and consistency matter more than physical realism
- **Target 10k+ entities** - Minimum 10k at 60 FPS, push higher if implementation allows

Ask the user:
- What physics behavior should this system implement?
- Any specific constraints or requirements for this system?

### Step 2: Use the Template

Copy `assets/physics-system-template.js` to `physics/<system-name>.js` in the project root. This template includes:
- Proper export structure
- Common control patterns
- Commented sections for each lifecycle hook
- Example entity iteration patterns

### Step 3: Implement the Core Logic

Focus on the `update(dt, settings, entities, input)` function:

```javascript
update(dt, settings, entities, input) {
  // dt: delta time in seconds
  // settings: object with all control values (including common ones)
  // entities: { count, x[], y[], type[] }
  // input: { x, y, mouseX, mouseY, ... }

  for (let i = 0; i < entities.count; i++) {
    // Calculate forces/velocities/directions
    // Update entities.x[i] and entities.y[i]
  }
}
```

### Step 4: Define Controls

Add tunable parameters in the `controls` object:

```javascript
controls: {
  paramName: {
    type: 'range',        // or 'checkbox'
    min: 0,
    max: 100,
    step: 1,
    default: 50,
    label: 'Human Readable Label',
    onChange: (value, engine) => {
      // Optional: handle special cases like re-initialization
    }
  }
}
```

### Step 5: Add Debug Visualization (Optional)

Implement the `render()` hook to draw debug information:

```javascript
render(ctx, settings, entities, debugMode) {
  if (!settings.showDebug) return;

  ctx.strokeStyle = '#ff00ff';
  ctx.lineWidth = 1;
  // Draw vectors, grids, zones, etc.
}
```

### Step 6: Register the System

Add the new system to `index.html`:

```javascript
import mySystem from './physics/my-system.js';

const physicsSystems = {
  'my-system': mySystem,
  // ... existing systems
};
```

Add dropdown option:
```html
<select id="physics-select">
  <option value="my-system">My System Name</option>
  <!-- ... existing options -->
</select>
```

### Step 7: Test and Iterate

1. Load the testbed in browser
2. Select the new physics system from dropdown
3. Tune parameters using controls
4. Use pause/step to debug behavior
5. Monitor FPS graph for performance
6. Export settings JSON when parameters are dialed in
7. Update default values in the physics file

## Common Patterns

### Spatial Data Structures

For O(n²) neighbor queries, consider implementing:
- Grid-based spatial hashing (see `references/spatial-hashing.md`)
- Quadtrees for dynamic spatial partitioning
- Uniform grid with cell lists

### State Management

If the physics system needs additional state beyond entity positions:

```javascript
// Initialize in init() or first update()
state: {
  velocities: null,
  grid: null
},

init(settings, entities, canvasInfo) {
  this.state.velocities = {
    x: new Float32Array(100000),
    y: new Float32Array(100000)
  };
}
```

### Performance Optimization

- Use TypedArrays (Float32Array, Uint8Array) for better performance
- Implement early exits for distance checks (distSq < radiusSq)
- Consider limiting neighbor searches to nearby entities
- Profile with high entity counts (10k+) to find bottlenecks

## Hot Reloading

When developing:
1. Make changes to the physics file
2. Save
3. Vite automatically hot-reloads the module
4. Simulation continues without losing entities
5. Check console for "🔥 Hot reloaded" confirmation

Note: If adding a new system, you'll need to refresh the browser once to register it in index.html.

## Resources

### assets/
- `physics-system-template.js` - Boilerplate template for new systems
- `example-simple.js` - Minimal working example
- `example-advanced.js` - Complex system with state management

### references/
- `physics-system-api.md` - Complete API documentation
- `game-design-context.md` - Survivor-style game physics challenges and design goals
