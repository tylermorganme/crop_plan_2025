# Physics System Builder Skill

A skill for creating new physics systems in the survivor-physics testbed.

## What This Skill Does

This skill guides the creation of modular physics systems that integrate seamlessly with the testbed infrastructure. It provides:

- Step-by-step workflow for implementing new physics
- Templates and boilerplate code
- API documentation and examples
- Common algorithm implementations
- Performance optimization patterns

## When to Use

Use this skill when you want to:
- Create a new physics system (e.g., boids, GPU physics, pathfinding)
- Port an existing physics algorithm to the testbed
- Implement crowd behavior or collision avoidance
- Experiment with movement algorithms

## What's Included

### SKILL.md
Complete workflow guide with 7 steps from requirements to testing.

### References
- **physics-system-api.md** - Complete API documentation for physics systems
- **spatial-hashing.md** - Efficient collision detection implementation
- **common-algorithms.md** - Steering behaviors, boids, flow fields, potential fields

### Assets
- **physics-system-template.js** - Boilerplate template for new systems
- **example-simple.js** - Minimal working example (simple kinematic)
- **example-advanced.js** - Complex example with state management (velocity-based)

## Installation

The skill has been packaged as `physics-system-builder.zip` and can be installed in Claude Code by placing it in the `.claude` directory.

## Quick Start Example

To create a new physics system:

1. Copy `assets/physics-system-template.js` to `physics/my-system.js`
2. Fill in the name, description, and controls
3. Implement the `update()` function
4. Register in `index.html`
5. Test with hot reloading

## Package Location

`/Users/tylermorgan/Documents/projects/survivor-physics/.claude/skill-creator/physics-system-builder.zip`
